import { createAction } from 'redux-actions';

export const changeLanguage = createAction('CHANGE_LANGUAGE');
