import React from 'react';
import { Text, View } from 'react-native';

import styles from './styles';

const OrderScreen = () => {
  return (
    <View style={styles.container}>
      <Text>Order Screen</Text>
    </View>
  );
};

export default OrderScreen;
