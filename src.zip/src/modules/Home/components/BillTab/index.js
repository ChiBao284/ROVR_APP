import React from 'react';

import BillScreen from './BillScreen';

const BillTab = () => {
  return <BillScreen />;
};

export default BillTab;
