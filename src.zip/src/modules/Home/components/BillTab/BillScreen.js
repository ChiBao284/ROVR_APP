import React from 'react';
import { Text, View } from 'react-native';

import styles from './styles';

const BillScreen = () => {
  return (
    <View style={styles.container}>
      <Text>Bill Screen</Text>
    </View>
  );
};

export default BillScreen;
