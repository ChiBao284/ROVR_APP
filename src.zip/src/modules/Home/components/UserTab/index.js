import React from 'react';

import UserScreen from './UserScreen';

const UserTab = () => {
  return <UserScreen />;
};

export default UserTab;
