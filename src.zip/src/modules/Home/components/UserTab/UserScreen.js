import React from 'react';
import { Text, View } from 'react-native';

import styles from './styles';

const UserScreen = () => {
  return (
    <View style={styles.container}>
      <Text>User Screen</Text>
    </View>
  );
};

export default UserScreen;
