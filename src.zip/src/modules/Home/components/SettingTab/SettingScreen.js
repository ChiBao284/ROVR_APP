import React from 'react';
import { Text, View } from 'react-native';

import styles from './styles';

const SettingScreen = () => {
  return (
    <View style={styles.container}>
      <Text>Setting Screen</Text>
    </View>
  );
};

export default SettingScreen;
