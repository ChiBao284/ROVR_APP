import React from 'react';

import SettingScreen from './SettingScreen';

const SettingTab = () => {
  return <SettingScreen />;
};

export default SettingTab;
