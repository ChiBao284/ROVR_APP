export default {
  success: {
    status: 401,
  },
  error: {
    status: 422,
    message: 'Your phone number does not exist. Please try again',
  },
};
