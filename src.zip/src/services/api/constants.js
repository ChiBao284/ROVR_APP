import Config from 'react-native-config';

export const { ENVIRONMENT, API_URL } = Config;
