import logIn from './logIn';

export default {
  ...logIn,
};
