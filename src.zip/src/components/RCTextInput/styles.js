import { StyleSheet } from 'react-native';

import { colors } from 'common/theme';

const styles = StyleSheet.create({
  textInput: {
    color: colors.black,
  },
});

export default styles;
